//
//  AppDelegate.h
//  My-club
//
//  Created by luckyaccount on 6/7/16.
//  Copyright (c) 2016 luckyaccount. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

