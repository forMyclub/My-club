//
//  main.m
//  My-club
//
//  Created by luckyaccount on 6/7/16.
//  Copyright (c) 2016 luckyaccount. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
